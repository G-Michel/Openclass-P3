// Exports the "visualchars" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/visualchars')
//   ES2015:
//     import 'tinymce/plugins/visualchars'
require('./plugin.js');